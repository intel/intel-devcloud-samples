# Applcation Metrics

Python package for sending job specific metrics from devcloud

for more information visit: https://github.com/intel-iot-devkit/iot-devcloud

